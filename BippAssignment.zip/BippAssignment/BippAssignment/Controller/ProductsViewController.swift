//
//  ProductsViewController.swift
//  BippAssignment
//
//  Created by admin on 28/12/21.
//

import UIKit

class ProductsViewController: UIViewController{
    //MARK:- IBOutlets
    @IBOutlet weak var productsTableView: UITableView!
    @IBOutlet weak var searchtextField: UITextField!
    @IBOutlet weak var filterButton: UIButton!
    //MARK:- Variable
    var dataSource:[CellInfo] = []
    var viewModel:ProductsViewModel = ProductsViewModel()
    var selectedFilter:[String:String] = [:]
    var products:[Product] = []
    
    //MARK:- View Lifecycle
    override func viewDidLoad() {
        super.viewDidLoad()
        self.navigationController?.navigationBar.isHidden = true
        self.registerXib()
        self.productsApiCall()
    }
    //MARK:- Private Functions
  func setupView(products:[Product]){
       dataSource = viewModel.productsCell(products: products)
        productsTableView.reloadData()
    }
    
   private func registerXib(){
        productsTableView.register(UINib(nibName:OddIndexCell.cellID, bundle: nil), forCellReuseIdentifier:OddIndexCell.cellID)
        productsTableView.register(UINib(nibName:EvenIndexCell.cellID, bundle: nil), forCellReuseIdentifier:EvenIndexCell.cellID)
    }
    
    private func presentFilterVC(){
        guard let productsFilterVc =  UIStoryboard(name: "Main", bundle: nil).instantiateViewController(withIdentifier: "ProductFilterViewController") as? ProductFilterViewController else {return}
        productsFilterVc.modalPresentationStyle = .overFullScreen
        productsFilterVc.delegate = self
        self.navigationController?.present(productsFilterVc, animated: true, completion:nil)
    }
    
    //MARK:- Apicall
    func productsApiCall(){
        viewModel.fetchProducts(endPoint: endPoint) {[self] products, errorMessage in
            if errorMessage != ""{
                AskConfirmation(title: errorMessage, message: "") { success in}
            }else{
                DispatchQueue.main.async {
                    filterButton.setTitle("Filter", for: .normal)
                    self.products = products
                    self.setupView(products: products)
                }
            }
        }
    }
    
    //MARK:- IBActions
    @IBAction func onTapBack(_ sender: UIButton) {
        self.navigationController?.popViewController(animated: true)
    }
    
    @IBAction func onTapFilter(_ sender: UIButton) {
        if sender.title(for: .normal) == "Remove Filter"{
            productsApiCall()
        }else{
        self.presentFilterVC()
        }
    }
}
//MARK:- Apply Filter
extension ProductsViewController:FilterDelegate{
    func getFilterData(selectedFilter: [String : String]) {
        
        let priceFilter = selectedFilter["Price"]
        let ratingFilter = selectedFilter["Rating"]
        
        if !(priceFilter == "" && ratingFilter == ""){
            filterButton.setTitle("Remove Filter", for: .normal)
        }
        
        switch priceFilter {
        case "Low to High":
            products = products.sorted{CGFloat($0.price ?? 0.0) < CGFloat($1.price ?? 0.0)}
        case "High to Low":
            products = products.sorted{CGFloat($0.price ?? 0.0) > CGFloat($1.price ?? 0.0)}
        default:
            break
        }
        switch ratingFilter {
        case "Low to High":
            products = products.sorted{CGFloat($0.rating?.rate ?? 0.0) < CGFloat($1.rating?.rate ?? 0.0)}
        case "High to Low":
            products = products.sorted{CGFloat($0.rating?.rate ?? 0.0) > CGFloat($1.rating?.rate ?? 0.0)}
        default:
           break
        }
        DispatchQueue.main.async {
            self.setupView(products: self.products)
        }
    }
    
    
}
