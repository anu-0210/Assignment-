//
//  Products+TableView.swift
//  BippAssignment
//
//  Created by admin on 31/12/21.
//

import Foundation
import UIKit

//MARK:- Tableview Datasource and Delegate--
extension ProductsViewController:UITableViewDelegate,UITableViewDataSource{
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return dataSource.count
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        return getCell(tableView: tableView, indexPath: indexPath, cellInfo: dataSource[indexPath.row])
    }
    
    func getCell(tableView: UITableView, indexPath: IndexPath, cellInfo:CellInfo)->UITableViewCell{
        guard let cellType = cellInfo.cellType else {
            return UITableViewCell()
        }
        switch cellType {
        case .oddIndexCell:
            guard let oddCell = tableView.dequeueReusableCell(withIdentifier: OddIndexCell.cellID) as? OddIndexCell else{
                return UITableViewCell()
            }
            oddCell.configureview(cellInfo: cellInfo)
            return oddCell
        case .evenIndexCell:
            guard let evenCell = tableView.dequeueReusableCell(withIdentifier: EvenIndexCell.cellID) as? EvenIndexCell else{
                return UITableViewCell()
            }
            evenCell.configureview(cellInfo: cellInfo)
            return evenCell
        }
        
    }
    
    func tableView(_ tableView: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat {
        return 200
    }
    
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        guard let productsDetailVc =  UIStoryboard(name: "Main", bundle: nil).instantiateViewController(withIdentifier: "ProductDetailViewController") as? ProductDetailViewController else {return}
        if let id = (dataSource[indexPath.row].dataObject as? Product)?.id{
        productsDetailVc.id = id
        productsDetailVc.viewModel = self.viewModel
        self.navigationController?.pushViewController(productsDetailVc, animated: true)
        }else{
            let errorMessage = "Product Detail not Available!"
            AskConfirmation(title: errorMessage, message: "") { success in}
        }
    }
    
}
//MARK:- Search Data on the basis of Title and description--
extension ProductsViewController:UITextFieldDelegate{
    func textFieldDidBeginEditing(_ textField: UITextField) {
        textField.text = ""
        if textField.text == ""{
            productsApiCall()
            resignFirstResponder()
        }
    }
    func textFieldShouldReturn(_ textField: UITextField) -> Bool {
        if textField.text?.count ?? 0 > 0{
            if let searchedText = textField.text{
                let filteredProducts = self.products.filter { $0.title?.localizedCaseInsensitiveContains(searchedText) ?? false || $0.description?.localizedCaseInsensitiveContains(searchedText) ?? false }
                setupView(products: filteredProducts)
            }
        }
        return true
    }
    
}
