//
//  ProductFilterViewController.swift
//  BippAssignment
//
//  Created by admin on 29/12/21.
//

import UIKit

protocol FilterDelegate {
    func getFilterData(selectedFilter:[String:String])
}

class ProductFilterViewController: UIViewController {
    //MARK:- IBOutlets
    @IBOutlet weak var priceHtoL: UIButton!
    @IBOutlet weak var priceLtoH: UIButton!
    @IBOutlet weak var ratingHtoL: UIButton!
    @IBOutlet weak var ratingLtoH: UIButton!
    @IBOutlet weak var bottomView: UIView!
    //MARK:- Variables
    var selectedFilter:[String:String] = [:]
    var delegate:FilterDelegate?
    //MARK:- View Lifecycle
    override func viewDidLoad() {
        super.viewDidLoad()
        self.setupGesture()
    }
    
    //MARK:- Private Functions
    private func setupGesture(){
        let swipeDown = UISwipeGestureRecognizer(target: self, action: #selector(self.respondToSwipeGesture))
        swipeDown.direction = UISwipeGestureRecognizer.Direction.down
        self.bottomView.addGestureRecognizer(swipeDown)
    }
    
    //MARK:- @objc Functions
    @objc func respondToSwipeGesture(gesture: UIGestureRecognizer) {
        if let swipeGesture = gesture as? UISwipeGestureRecognizer {
            switch swipeGesture.direction {
            case UISwipeGestureRecognizer.Direction.right:
                print("Swiped right")
            case UISwipeGestureRecognizer.Direction.down:
                print("Swiped down")
                self.dismiss(animated: true, completion: nil)
            case UISwipeGestureRecognizer.Direction.left:
                print("Swiped left")
            case UISwipeGestureRecognizer.Direction.up:
                print("Swiped up")
            default:
                break
            }
        }
    }

    //MARK:- IBActions
   
    @IBAction func onTapRatingLowToHigh(_ sender: UIButton) {
        self.ratingLtoH.isSelected = !sender.isSelected
        let image = ratingLtoH.isSelected ? UIImage(systemName: "checkmark.square") : UIImage(systemName: "square")
        ratingLtoH.setImage(image, for: .normal)
        ratingHtoL.setImage(UIImage(systemName: "square"), for: .normal)
        if  self.ratingLtoH.isSelected{
            selectedFilter["Rating"] = sender.title(for: .normal)
        }
    }
    
    @IBAction func onTapRatinghighTolow(_ sender: UIButton) {
        self.ratingHtoL.isSelected = !sender.isSelected
        let image = ratingHtoL.isSelected ? UIImage(systemName: "checkmark.square") : UIImage(systemName: "square")
        ratingHtoL.setImage(image, for: .normal)
        ratingLtoH.setImage(UIImage(systemName: "square"), for: .normal)
        if  self.ratingHtoL.isSelected{
            selectedFilter["Rating"] = sender.title(for: .normal)
        }
    }
    
    
    @IBAction func onTapPriceLowToHigh(_ sender: UIButton) {
        self.priceLtoH.isSelected = !sender.isSelected
        let image = priceLtoH.isSelected ? UIImage(systemName: "checkmark.square") : UIImage(systemName: "square")
        priceLtoH.setImage(image, for: .normal)
        priceHtoL.setImage(UIImage(systemName: "square"), for: .normal)
        if  self.priceLtoH.isSelected{
            selectedFilter["Price"] = sender.title(for: .normal)
        }
    }
    
    @IBAction func onTapPriceHighToLow(_ sender: UIButton) {
        self.priceHtoL.isSelected = !sender.isSelected
        let image = priceHtoL.isSelected ? UIImage(systemName: "checkmark.square") : UIImage(systemName: "square")
        priceHtoL.setImage(image, for: .normal)
        priceLtoH.setImage(UIImage(systemName: "square"), for: .normal)
        if  self.priceHtoL.isSelected{
            selectedFilter["Price"] = sender.title(for: .normal)
        }
    }
    
    @IBAction func onTapdismissViewButton(_ sender: UIButton) {
        self.dismiss(animated: true,completion: nil)
        
    }
    
    
    @IBAction func onTapDone(_ sender: UIButton) {
        delegate?.getFilterData(selectedFilter: self.selectedFilter)
        self.dismiss(animated: true,completion: nil)
    }
    
}
