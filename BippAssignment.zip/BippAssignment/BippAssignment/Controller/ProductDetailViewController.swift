//
//  ProductDetailViewController.swift
//  BippAssignment
//
//  Created by admin on 28/12/21.
//

import UIKit
import Cosmos
class ProductDetailViewController: UIViewController {
    
    //MARK:- IBOutlets
    @IBOutlet weak var descriptionLabel: UILabel!
    @IBOutlet weak var productImage: UIImageView!
    @IBOutlet weak var titleLabel: UILabel!
    @IBOutlet weak var categoryLabel: UILabel!
    @IBOutlet weak var totalRatings: UILabel!
    @IBOutlet weak var ratingView: CosmosView!
    @IBOutlet weak var priceButton: UIButton!
    //MARK:- Variable
    var id:Int?
    var viewModel:ProductsViewModel?
    //MARK:- View Lifecycle
    override func viewDidLoad() {
        super.viewDidLoad()
        self.productDetailApiCall()
       
    }
    //MARK:- Private Functions
    private func setupView(product:Product){
        guard let imageUrl = product.image, let title = product.title, let description = product.description , let category = product.category, let rating = product.rating, let price = product.price else{return}
        descriptionLabel.text = description
        productImage.loadImageUsingCache(withUrl: imageUrl)
        titleLabel.text = title
        categoryLabel.text = category
        totalRatings.text = rating.count?.description
        ratingView.rating = rating.rate ?? 0.0
        priceButton.setTitle(String(price), for: .normal)
    }
    
    //MARK:- Apicall
    func productDetailApiCall(){
        guard let productID = self.id else {return}
        viewModel?.fetchProductDetail(productId:productID) {[self] product, errorMessage in
            if errorMessage != ""{
                AskConfirmation(title: errorMessage, message: "") { success in}
            }else{
                DispatchQueue.main.async {
                    if let product = product{
                    self.setupView(product: product)
                    }
                }
            }
        }
    }
    
    
    //MARK:- IBActions
    @IBAction func onTapBack(_ sender: UIButton) {
        self.navigationController?.popViewController(animated: true)
    }
    

}
