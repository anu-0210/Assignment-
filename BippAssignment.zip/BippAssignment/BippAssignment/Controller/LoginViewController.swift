//
//  LoginViewController.swift
//  BippAssignment
//
//  Created by admin on 28/12/21.
//

import UIKit

class LoginViewController: UIViewController {
    //MARK:- IBOutlets
    @IBOutlet weak var passwordTextField: UITextField!
    @IBOutlet weak var loginTextView: UIButton!
    @IBOutlet weak var emailTextField: UITextField!
    @IBOutlet weak var loginView: UIView!
    @IBOutlet weak var loginButton: UIButton!
    @IBOutlet weak var logoImageView: UIImageView!
    
    //MARK:- Variable
    var viewModel:LoginViewModel = LoginViewModel()
    
    //MARK:- View Lifecycle
    override func viewDidLoad() {
        super.viewDidLoad()
        self.setupView()
        self.emailTextField.becomeFirstResponder()
    }
    
    //MARK:- Private Functions
    private func setupView(){
        self.navigationController?.navigationBar.isHidden = true
        self.loginTextView.roundCorners(corners: .allCorners, radius: 16)
        self.logoImageView.dropShadow(color: #colorLiteral(red: 0.9019607843, green: 0.2235294118, blue: 0.2745098039, alpha: 1))
        self.loginButton.roundCorners(corners: .allCorners, radius: 8)
    }
    
   private func isValidUser() -> Bool{
        var isValid = true
        guard let email = emailTextField.text , let password = passwordTextField.text else{return false}
        let authDetail = Authentication(password:password , email: EmailPropertyWrapper(_emailValue: email))
        viewModel.validateLogin(auth:authDetail) { success, message in
            if !success{
                isValid = false
                AskConfirmation(title: message, message: "") { success in}
            }
        }
       return isValid
    }
    
    //MARK:- IBActions
    @IBAction func onTapLogin(_ sender: UIButton) {
        if self.isValidUser() {
            guard let productsVc =  UIStoryboard(name: "Main", bundle: nil).instantiateViewController(withIdentifier: "ProductsViewController") as? ProductsViewController else {return}
            self.navigationController?.pushViewController(productsVc, animated: true)
        }
    }
    
    
    
}
