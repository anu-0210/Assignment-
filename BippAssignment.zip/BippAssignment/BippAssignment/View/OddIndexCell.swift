//
//  OddIndexCell.swift
//  BippAssignment
//
//  Created by admin on 30/12/21.
//

import UIKit

class OddIndexCell: UITableViewCell {
    static let cellID = "OddIndexCell"
    @IBOutlet weak var productDescription: UILabel!
    @IBOutlet weak var title: UILabel!
    @IBOutlet weak var productImage: UIImageView!
    @IBOutlet weak var innerView: UIView!
    
    @IBOutlet weak var ratingButton: UIButton!
    @IBOutlet weak var priceButton: UIButton!
    override func awakeFromNib() {
        super.awakeFromNib()
        //innerView.roundCorners(corners: .allCorners, radius: 8)
        innerView.dropShadow(color: #colorLiteral(red: 0.1137254902, green: 0.2078431373, blue: 0.3411764706, alpha: 1))
    }

    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)

        // Configure the view for the selected state
    }
    
    func configureview(cellInfo:CellInfo){
        guard let product = cellInfo.dataObject as? Product else{return}
        productDescription.text = product.description
        title.text = product.title
        priceButton.setTitle(String(product.price ?? 0.0), for: .normal)
        ratingButton.setTitle(String(product.rating?.rate ?? 0.0), for: .normal)
        if let imgeUrl = product.image{
        productImage.loadImageUsingCache(withUrl:imgeUrl)
        }
    }
    
}
