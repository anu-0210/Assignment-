//
//  Constants.swift
//  BippAssignment
//
//  Created by admin on 28/12/21.
//

import Foundation
import UIKit

let defaultEmailId = "bipp123@gmail.com"
let defaultPassword = "bipp@123"

let emailData = Data(defaultEmailId.utf8)
let passwordData = Data(defaultPassword.utf8)
let baseUrl = "https://fakestoreapi.com"
let endPoint = "/products"


struct Constants {
   static let kEmail = "Email"
   static let kPassword = "Password"
   static let kAccount = "dummy.com"
}
