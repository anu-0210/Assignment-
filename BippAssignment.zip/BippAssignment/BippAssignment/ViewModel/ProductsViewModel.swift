//
//  ProductsViewModel.swift
//  BippAssignment
//
//  Created by admin on 30/12/21.
//

import Foundation

class ProductsViewModel{
    
    func productsCell(products:[Product])->[CellInfo]{
        var cells:[CellInfo] = []
        for i in 0..<products.count{
            if i%2 == 0{
        let oddCell = CellInfo(cellType: .oddIndexCell,dataObject: products[i])
        cells.append(oddCell)
            }else{
        let evenCell = CellInfo(cellType: .evenIndexCell,dataObject: products[i])
        cells.append(evenCell)
            }
        }
        
        return cells
    }
    
    func fetchProducts(endPoint:String,completionHandler: @escaping ([Product],String) -> Void) {
        let url = URL(string: baseUrl + endPoint)!

        let task = URLSession.shared.dataTask(with: url, completionHandler: { (data, response, error) in
          if let error = error {
            let errormessgae = "Error with fetching Product: \(error)"
            completionHandler([],errormessgae)
            return
          }
          
          guard let httpResponse = response as? HTTPURLResponse,
                (200...299).contains(httpResponse.statusCode) else {
            let errormessgae = "Error with the response, unexpected status code: \(response)"
            completionHandler([],errormessgae)
            return
          }

          if let data = data,
            let products = try? JSONDecoder().decode([Product].self, from: data) {
            completionHandler(products ,"")
          }
        })
        task.resume()
      }
    
    func fetchProductDetail(productId:Int,completionHandler: @escaping (Product?,String) -> Void) {
        let url = URL(string: baseUrl + endPoint + "/\(productId)")!

        let task = URLSession.shared.dataTask(with: url, completionHandler: { (data, response, error) in
          if let error = error {
            let errormessgae = "Error with fetching Product: \(error)"
            completionHandler(nil,errormessgae)
            return
          }
          
          guard let httpResponse = response as? HTTPURLResponse,
                (200...299).contains(httpResponse.statusCode) else {
            let errormessgae = "Error with the response, unexpected status code: \(response)"
            completionHandler(nil,errormessgae)
            return
          }

          if let data = data,
            let product = try? JSONDecoder().decode(Product.self, from: data) {
            completionHandler(product ,"")
          }
        })
        task.resume()
      }
}
