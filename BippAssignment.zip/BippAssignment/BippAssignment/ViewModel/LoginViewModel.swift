//
//  LoginViewModel.swift
//  BippAssignment
//
//  Created by admin on 29/12/21.
//

import Foundation
class LoginViewModel{
    var email:String?
    var password:String?
    
    func validateLogin(auth:Authentication,completion:((Bool,String) -> Void)){
        self.retriveUserLoginDetail()
        guard let loginEmail = self.email,let loginPassword = self.password else {
            completion(false,"Data Not Found!")
            return
        }
        
        auth.validate { success, message in
            if success{
                if auth.email != loginEmail{
                    completion(false,"Email not registered")
                }
                else if auth.password != loginPassword{
                    completion(false,"Wrong Password")
                }else{
                    completion(true,"Login Successfully")
                }
            }else{
                completion(false,message ?? "Some error found")
            }
        }
        
    }
    
    func retriveUserLoginDetail(){
        guard let emailData = KeychainHelper.standard.read(service: Constants.kEmail, account:Constants.kAccount) , let passwordData = KeychainHelper.standard.read(service:Constants.kPassword, account:Constants.kAccount) else{
            return }
        self.email = String(data: emailData, encoding: .utf8)
        self.password = String(data: passwordData, encoding: .utf8)
        
    }
    
    
    
}
