//
//  Authentication.swift
//  BippAssignment
//
//  Created by admin on 29/12/21.
//

import Foundation
import Foundation
@propertyWrapper
struct EmailPropertyWrapper
{
    private var _value: String
    var wrappedValue: String
    {
        get
        {
            if _value == ""{
              return "Empty Email"
            }else{
            return isValidEmail(email: _value) ? _value : "Invalid Email"
            }
        }
        set
        {
            _value = newValue
        }
    }

    init(_emailValue: String) {
        _value = _emailValue
    }

    private func isValidEmail(email: String) -> Bool {
        let regex = "[A-Z0-9a-z._%+-]+@[A-Za-z0-9.-]+\\.[A-za-z]{2,64}"
        let pred = NSPredicate(format: "SELF MATCHES %@", regex)
        return pred.evaluate(with: email)
    }
}


struct Authentication
{
    var password: String
    @EmailPropertyWrapper var email: String

    func validate(completion:(Bool,String?)->Void)
    {
        if(password.isEmpty)
        {
          completion(false,"Password can't be empty!")
        }else if email == "Empty Email"{
            completion(false,"Email can't be empty!")
        }else if email == "Invalid Email"{
            completion(false,"Invalid Email")
        }
        else{
            completion(true,"Login Successfully!")
        }
       
    }
}
