//
//  CellInfo.swift
//  BippAssignment
//
//  Created by admin on 30/12/21.
//

import Foundation
import UIKit
struct CellInfo {
    
    var cellType: CellType!
    var placeHolder: String!
    var topLayoutConstraint: CGFloat!
    var value: String!
    var valueTwo: String!
    var height: CGFloat!
    var labelPlaceholder: String!
    var info: [String: Any]?
    var isSecureText: Bool!
    var returnKeyType: UIReturnKeyType!
    var keyboardType: UIKeyboardType!
    var capitalizationType: UITextAutocapitalizationType!
    var isUserInteractionEnabled: Bool!
    var placeHolderColor: UIColor!
    var buttonTextColor: UIColor!
    var dataObject: Any?
    var eventData:Any?
    var buttonTitle: String?
    var textSize:CGFloat?
    var objectArray: [Any]
    var quantity:Int!
    var isSelected:Bool? = false

    
    init(cellType: CellType, placeHolder: String = "", topLayoutConstraint: CGFloat = 0 ,value: String = "",valueTwo: String = "", info:[String: Any]? = nil, isSecureText: Bool = false, height: CGFloat = UITableView.automaticDimension, labelPlaceholder: String = "", returnKeyType: UIReturnKeyType = .done, keyboardType: UIKeyboardType = .default, capitalizationType: UITextAutocapitalizationType = .none, placeHolderColor: UIColor = UIColor.black, isUserInteractionEnabled: Bool = true,buttonTextColor: UIColor = UIColor.white, dataObject:Any? = nil,buttonTitle:String = "",textSize:CGFloat? = nil, objectArray:[Any] = [],quantity:Int = 0,isSelected:Bool? = false) {
        self.cellType = cellType
        self.placeHolder = placeHolder
        self.topLayoutConstraint = topLayoutConstraint
        self.value = value
        self.valueTwo = valueTwo
        self.placeHolder = placeHolder
        self.height = height
        self.labelPlaceholder = labelPlaceholder
        self.info = info
        self.isSecureText = isSecureText
        self.returnKeyType = returnKeyType
        self.keyboardType = keyboardType
        self.capitalizationType = capitalizationType
        self.isUserInteractionEnabled = isUserInteractionEnabled
        self.placeHolderColor = placeHolderColor
        self.buttonTextColor = buttonTextColor
        self.dataObject = dataObject
       
        self.buttonTitle = buttonTitle
       
        self.textSize = textSize
        self.objectArray = objectArray
        self.quantity = quantity
        self.isSelected = isSelected

    }
}

enum CellType{
   case oddIndexCell
   case evenIndexCell
}


